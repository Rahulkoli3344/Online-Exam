package com.kiranacademy.onlineexam3;

import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class QuestionController {
	
	@Autowired
	SessionFactory factory;
	
	@RequestMapping("endexam")
	public ModelAndView endexam(HttpServletRequest request) 
	{
		HttpSession httpsession=request.getSession();
		HashMap<Integer,Answer> hashmap=(HashMap) httpsession.getAttribute("submittedDetails");
		
		ModelAndView modelAndView =new ModelAndView();
		
		if(hashmap==null)
		{
		    modelAndView.setViewName("welcome");
		}
		
		else
		{
		Collection<Answer> allAnswers=hashmap.values();
		
		for (Answer answer : allAnswers) {
			
			if(answer.originalAnswer.equals(answer.submittedAnswer))
			{
				   httpsession.setAttribute("score",(Integer)httpsession.getAttribute("score")+1);
			}
		}
			
			
			Session hibernateSession = factory.openSession();
			
			Transaction tx = hibernateSession.beginTransaction();
			
							Score  score = new Score();
							
							score.setUsername((String)httpsession.getAttribute("username"));
							score.setSubject((String)httpsession.getAttribute("subject"));
							score.setMarks((Integer)httpsession.getAttribute("score"));
			
							hibernateSession.save(score);
					
			tx.commit();
			
		//ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("score");
		modelAndView.addObject("finalscore",httpsession.getAttribute("score"));
		modelAndView.addObject("allAnswers",allAnswers);
		
		httpsession.invalidate();
		}
		return modelAndView;
			
	}
		
	@RequestMapping("next")
	public ModelAndView next(HttpServletRequest request) {
		
		HttpSession  httpsession=request.getSession();
		
			Integer i= (Integer) httpsession.getAttribute("qno");
			int nextQno=i+1;
			
			List<Questions> list=(List<Questions>) httpsession.getAttribute("allquestions");
			
			ModelAndView modelAndView =new ModelAndView();
			modelAndView.setViewName("questions");
			
			if(nextQno<list.size())
			{
				
				  Questions question=list.get(nextQno);
				  
				  modelAndView.addObject("question",question);
				  
				  httpsession.setAttribute("qno",nextQno);
				  
				  HashMap<Integer,Answer> hashmap=(HashMap) httpsession.getAttribute("submittedDetails");
					 Answer answer=hashmap.get(question.qno);
					 
					 String previousAnswer="";
					 
					 if(answer!=null) 
					 {
						  previousAnswer=answer.getSubmittedAnswer();
					 }
					
					modelAndView.addObject("previousAnswer",previousAnswer);
					
				  }
			
			   else
			  {
				
				modelAndView.addObject("question",list.get(list.size()-1));
				modelAndView.addObject("message", "click on previous button");
			}
		  
			return modelAndView;
		
	}
	

	@RequestMapping("previous")
	public ModelAndView previous(HttpServletRequest request) {
		
		HttpSession  httpsession=request.getSession();
		
			Integer i=(Integer)httpsession.getAttribute("qno");
			int previousQno=i-1;
			
			List<Questions> list=(List<Questions>) httpsession.getAttribute("allquestions");
			
			ModelAndView modelAndView =new ModelAndView();
			modelAndView.setViewName("questions");
			
			if(previousQno>=0)
			{
				 Questions question=list.get(previousQno);
			  
				  modelAndView.addObject("question",question);
				  
				  httpsession.setAttribute("qno",previousQno);
				  
			 HashMap<Integer,Answer> hashmap=(HashMap) httpsession.getAttribute("submittedDetails");
			 Answer answer= hashmap.get(question.qno);
			 
			 String previousAnswer="";
			 
			 if(answer!=null) 
			 {
				  previousAnswer=answer.getSubmittedAnswer();
			 }
			
			modelAndView.addObject("previousAnswer",previousAnswer);
			
			}
			
			else
				
			{
				
				modelAndView.addObject("question",list.get(0));
				modelAndView.addObject("message", "click on next button");
			}
			
		  
			return modelAndView;
		
	}
	@RequestMapping("saveResponse")
	public void saveResponse(Answer answer,HttpServletRequest request) {
		
		System.out.println(answer);
		
		HttpSession httpsession=request.getSession();
		List<Questions> list=(List<Questions>) httpsession.getAttribute("allquestions");
		
		
		for (Questions questions : list) {
			
			
			if(questions.qno==answer.qno) {
				
				      String ans=questions.answer;
				      answer.setOriginalAnswer(ans);
				      break;	      
				}
			}
		
		System.out.println(answer);
		
		HashMap<Integer,Answer> map=(HashMap) httpsession.getAttribute("submittedDetails");
		map.put(answer.qno, answer);
		
		System.out.println(map);
	
		
		
	}
	

}
